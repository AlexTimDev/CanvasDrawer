<template>
  <div class="tool">
    <ul>
      <li v-for="toolName in toolNames" v-bind:key="toolName">
        <div
          :title="toolName.firstUpperCase() + ' Tool'"
          @mousedown="switchTool(toolName)"
        >
          <img
            :src="'assets/images/tools/' + tools[toolName].image"
            style="width:24px"
          />
        </div>
      </li>
    </ul>
    <div class="color">
      <!-- <div id="color-reset" title="Reset Color" @click="resetColor"></div>
      <div
        id="color-exchange"
        title="Exchange between forecolor and backcolor"
        @click="exchangeColor"
      ></div> -->
      <div id="display-color">
        <div
          id="fore-color"
          :style="foreColorStyle"
          title="Foreground color"
          style=""
          @click="openColorPicker"
        ></div>
        <div
          id="back-color"
          :style="backColorStyle"
          title="Background color"
          @click="openColorPicker(false)"
        ></div>
      </div>
    </div>
  </div>
</template>

<script>
//    import '../color-picker/color-picker.min.css';
import Tools from "./tools";
import Nox from "@/components/nox";
import documentEvent from './document-event';

export default {
  data() {
    return {
      toolNames: Object.keys(Tools),
      tools: Tools
    };
  },
  computed: {
    activeTool() {
      return this.$store.getters.activeTool;
    },
    foreColorStyle() {
      return {
        // backgroundColor: "#" + this.$store.getters.foreColor
        "border-color": "#" + this.$store.getters.foreColor
      };
    },
    backColorStyle() {
      return {
        backgroundColor: "#" + this.$store.getters.backColor
      };
    }
  },
  methods: {
    switchTool(tool) {
      if (tool == "zoomIn" || tool == "zoomOut") {
        documentEvent.$emit("switchTool", tool);
      } else {
        this.$store.commit("switchTool", tool);
        let foreColor = '#'+this.$store.getters.foreColor;
        let backColor = '#'+this.$store.getters.backColor;
        this.$store.commit("newPixelItem", { type: tool, foreColor, backColor});
      }
    },
    exchangeColor() {
      this.$store.commit("exchangeColor");
    },
    resetColor() {
      this.$store.commit("resetColor");
    },
    openColorPicker(isForeColor = true) {
      if (isForeColor) {
        Nox.openWindow("Color Picker", "foreColor");
        // documentEvent.$emit("switchTool", 'foreColor');
      } else {
        Nox.openWindow("Color Picker", "backColor");
        // documentEvent.$emit("switchTool", 'backColor');
      }
    }
  }
};
</script>

<style lang="scss" scoped="">
.tool {
  position: absolute;
  left: 1em;
  top: 100px;
  height: 450px;
  width: 80px;
  background-color: white;
  box-shadow: 0 0 0.8em #000000;
  border: solid #808080 1px;
  border-radius: 10px;
  user-select: none;
}
.tool > ul {
  margin: 0;
  padding: 0;
  list-style-type: none;
}
.tool > ul > li {
  display: flex;
  justify-content: center;
  align-items: center;
}
.tool > ul div {
  display: inline-block;
  font-size: 2em;
  padding: 0.4em;
  margin: 0.2em;
  border-radius: 5px;
  width: 50px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #f0f0f0;
}
.tool > ul div:hover {
  background: #d0d0d0;
}
.tool > ul div.active {
  background: #2c2c2c;
}
.tool .color {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 80px;
  padding: 10px;
}
.tool .color #display-color {
  width: 100%;
  height: 100%;
}
.tool .color #color-reset,
.tool .color #color-exchange {
  display: inline-block;
  width: 0.7em;
  height: 0.7em;
  padding: 0.1em;
  margin-bottom: 0.2em;
}
.tool .color #color-reset {
  background: url("/assets/images/ResetColor.svg");
}
.tool .color #color-exchange {
  background: url("/assets/images/ExchangeColor.svg");
}
.tool #display-color {
  position: relative;
  background-color: lightgrey;
  border: solid lightgrey 10px;
  border-radius: 5px;
}
.tool .color #display-color div {
  position: absolute;
  width: 1em;
  height: 1em;
}
.tool .color #display-color #fore-color {
  width: 25px;
  height: 25px;
  right: 0px;
  bottom: 0px;
  // background: #000;
  border: 0.15em solid #fff;
  //outline: 0.1em solid #000;
  z-index: 0;
}
.tool .color #display-color #back-color {
  width: 25px;
  height: 25px;
  left: 0px;
  top: 0px;
  background: #fff;
  // border: 0.05em solid #fff;
  // outline: 0.1em solid #000;
  z-index: 0;
}
</style>
