<template>
  <div id="app">
    <div class="top">
      <menu-bar></menu-bar>
      <!-- <div id="full-screen" class="iconfont icon-quanping" @click="switchFullScreen"></div> -->
    </div>
    <div class="bottom-container">
      <!-- <tool-bar></tool-bar> -->
      <design-boards></design-boards>
    </div>
    <window-group></window-group>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import Nox from "@/components/nox";
import ColorPicker from "@/components/windows/ColorPicker.vue";

import MenuBar from "./Menu.vue";
// import Tool from "./Tool.vue";
import DesignBoard from "./DocumentManager.vue";
import WindowGroup from "./WindowGroup.vue";

export default {
  computed: mapGetters([
    // 'pixelDocuments'
  ]),
  components: {
    "menu-bar": MenuBar,
    // "tool-bar": Tool,
    "design-boards": DesignBoard,
    "window-group": WindowGroup
  },
  data() {
    return {};
  },
  methods: {}
};

window.onbeforeunload = function(event) {
  return "Unsaved works will be lost";
};
</script>

<style lang="scss"></style>
