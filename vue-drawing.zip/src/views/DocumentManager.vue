<template>
  <div id="design-boards">
    <tool-bar v-if="isShowToolbar"></tool-bar>
    <div class="document-bar" style="height: 40px;">
      <div
        v-for="item in pixelDocuments"
        class="document-item"
        :class="item === activeDocument ? 'active' : ''"
        :key="item.id"
      >
        <span class="title" @click.stop="switchTo(item)">{{
          item.fileName
        }}</span>
        <span
          class="close fa fa-times"
          @click.stop="closeDocument(item)"
        ></span>
      </div>
      <div class="document-new" @click.stop="openWindow('New')">
        +
      </div>
    </div>
    <ul class="pixel-documents">
      <li
        v-for="pixelDocument in pixelDocuments"
        :key="pixelDocument.id"
        is="PixelDocument"
        :isActive="pixelDocument === activeDocument"
        :docInfo="pixelDocument"
        @click.native="switchTo(pixelDocument)"
        @close="closeDocument(pixelDocument)"
      ></li>
    </ul>
  </div>
</template>

<script>
import { mapGetters, mapMutations } from "vuex";
import tools from "./tools";
import Document from "./Document.vue";
import Tool from "./Tool.vue";
import instruction from "./instruction";
import Nox from "@/components/nox";

export default {
  mixins: [instruction],
  components: {
    "tool-bar": Tool,
    PixelDocument: Document
  },
  data() {
    return {
      tools: tools
    };
  },
  mounted() {

  },
  computed: {
    ...mapGetters(["isShowToolbar", "pixelDocuments", "activeDocument", "activeTool"])
  },
  methods: {
    ...mapMutations(["initDocumentRes, addItem", "switchTo", "closeDocument"]),
    openWindow(windowTitle) {
      Nox.openWindow(windowTitle);
    }
  }
};
</script>

<style lang="scss" scoped="">
#design-boards {
  position: relative;
  height: 100%;
  margin: 0;
  z-index: 1;
  overflow: hidden;
}
.document-bar {
  height: 40px;
  font-size: 1.3em;
  background: #e0e0e0;
  display: flex;
  justify-content: flex-start;
  align-items: flex-start;
}
.document-item {
  height: 100%;
  display: flex;
  justify-content: center;
  align-content: center;
  background: #d0d0d0;
  margin-right: 3px;
  .title {
    overflow-wrap: break-word;
    word-break: break-all;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    margin-left: 5px;
    margin-right: 5px;
  }
  .close {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 1em;
    height: 100%;
    padding: 0.2em 0.1em 0.2em 0.3em;
    margin-left: 0;
    margin-right: 10px;
  }
  &:hover {
    background: #a0a0a0;
  }
  &.active {
    background: #b0b0b0;
    box-shadow: 0 0 0.2em #000000;
  }
}
.document-new {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  font-size: 40px;
  margin-left: 15px;
  margin-right: 15px;
  &:hover {
    color: #9b9999;
  }
}
ul.pixel-documents {
  font-size: 1.3em;
  // margin-bottom: 0.3em;
  list-style-type: none;
  // background: #3b3b3b;
}
</style>
