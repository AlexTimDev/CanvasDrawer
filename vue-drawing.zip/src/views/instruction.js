import store from "@/store/index";
import Nox from "@/components/nox";

export default {
  methods: {
    openFromLocal() {
      if (!FileReader) {
        return Nox.openWindow("Can't Read Local File");
      }
      let inpFile = document.createElement("input");
      inpFile.type = "file";
      inpFile.click();
      inpFile.onchange = function() {
        if (this.value) {
          let reader = new FileReader(),
            file = this.files[0];
          reader.readAsText(file);
          reader.addEventListener(
            "load",
            function() {
              let documentInfo = JSON.parse(this.result);
              store.commit("openDocument", documentInfo);
            },
            false
          );
        }
      };
    },
    save() {
      let activeDoc = store.getters.activeDocument;
      console.log('------------------documentSave:', activeDoc)
      let fileOutputLink = document.createElement('a');

      let filename = activeDoc.fileName + '.json';
      filename = window.prompt('Insert output filename', filename);
      if (!filename) return;
    
      let output = JSON.stringify(activeDoc);
      let data = new Blob([output], {type: 'text/plain'});
      let url = window.URL.createObjectURL(data);
      fileOutputLink.setAttribute('download', filename);
      fileOutputLink.href = url;
      fileOutputLink.style.display = 'none';
      document.body.appendChild(fileOutputLink);
      fileOutputLink.click();
      document.body.removeChild(fileOutputLink);
    },
    about() {
      store.commit("openWindow", "about");
    }
  }
};
