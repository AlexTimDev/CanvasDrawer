export default {
  symbol: {
    icon: "fa fa-location-arrow",
    image: "symbol.png"
  },
  shape: {
    icon: "fa fa-square-o",
    image: "rectangle.png"
  },
  arrow: {
    icon: "fa fa-long-arrow-right",
    image: "arrow.png"
  },
  text: {
    icon: "fa fa-font",
    image: "text.png"
  },
  zoomIn: {
    icon: "fa fa-search-plus",
    image: "zoomIn.png"
  },
  zoomOut: {
    icon: "fa fa-search-minus",
    image: "zoomOut.png"
  }
};
