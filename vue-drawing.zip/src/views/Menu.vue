<template>
  <nox-menu>
    <nox-ml title="File">
      <nox-mi hotkey="Alt+N" @click="openWindow('New')">New...</nox-mi>
      <nox-mi @click="openFromLocal" hotkey="Alt+O">Open From Local...</nox-mi>
      <nox-mi @click="save">Save</nox-mi>
    </nox-ml>
    <nox-ml title="Edit">
      <nox-mi @click="undo()">Undo</nox-mi>
      <!-- <nox-mi>Redo</nox-mi> -->
    </nox-ml>
    <nox-ml title="View">
      <nox-mi @click="zoomIn()">Zoom In</nox-mi>
      <nox-mi @click="zoomOut()">Zoom Out</nox-mi>
    </nox-ml>
    <nox-ml title="Tools">
      <nox-mi @click="showToolbar(true)">Show</nox-mi>
      <nox-mi @click="showToolbar(false)">Hode</nox-mi>
    </nox-ml>
    <nox-ml title="Help">
      <nox-mi @click="openWindow('About')">About</nox-mi>
    </nox-ml>
  </nox-menu>
</template>

<script>
import store from "@/store/index";
import instruction from "./instruction";
import Nox from "@/components/nox";
import documentEvent from './document-event';
import { mapGetters, mapMutations } from "vuex";

export default {
  mixins: [instruction],
  methods: {
    ...mapMutations(["showToolbar"]),
    openWindow(windowTitle) {
      Nox.openWindow(windowTitle);
    },
    undo() {
      documentEvent.$emit("switchTool", "undo");
    },
    zoomIn() {
      documentEvent.$emit("switchTool", "zoomIn");
    },
    zoomOut() {
      documentEvent.$emit("switchTool", "zoomOut");
    }
  }
};
</script>

<style></style>
