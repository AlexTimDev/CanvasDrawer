<template>
  <li :class="isActive ? 'active' : ''">
    <div class="board" v-show="isActive" @wheel="onwheel" ref="board">
      <ul
        class="canvases"
        :style="canvasesStyle"
        :class="classOfCanvases"
        @mouseup="onmouseup"
        @mousedown="onmousedown"
        ref="canvasContainer"
      >
        <li :is="'DocumentLayer'" ref="canvases" :docInfo="docInfo"></li>
      </ul>
    </div>
    <div class="status" v-show="isActive">{{ statusText }}</div>
  </li>
</template>

<script>
import color from "@/utils/color";
import DocumentLayer from "./DocumentLayer.vue";
import tools from "./tools";
import documentEvent from './document-event';

export default {
  components: {
    DocumentLayer: DocumentLayer
  },
  props: {
    isActive: Boolean,
    docInfo: Object
  },
  data() {
    return {
      scaling: 1,
      width: this.docInfo.width,
      height: this.docInfo.height,
      pos: "absolute",
      left: "50%",
      top: "0px",
      marginLeft: (-1 * this.docInfo.width) / 2,
      marginTop: "0px", // (-1 * this.docInfo.height) / 2,
      isAltKeyPress: false
    };
  },
  computed: {
    classOfCanvases() {
      return this.isAltKeyPress ? this.activeTool + "-alt" : this.activeTool;
    },
    activeTool() {
      return this.$store.getters.activeTool;
    },
    changeScaling: {
      get() {
        return this.scaling;
      },
      set(value) {
        this.scaling = value;
        this.scaling = this.scaling > 32 ? 32 : this.scaling;
        this.scaling = this.scaling < 0.1 ? 0.1 : this.scaling;

        //Forced re-rendering, fixed a bug where the scroll bar does not appear when the content exceeds or does not disappear when not exceeded
        this.pos = "relative";
        let _this = this;
        setTimeout(function() {
          _this.pos = "absolute";
        }, 0);
      }
    },
    canvasesStyle() {
      return {
        position: this.pos,
        cursor: this.$store.getters.activeTool.cursor,
        width: this.docInfo.width + "px",
        height: this.docInfo.height + "px",
        left: this.left,
        top: this.top,
        marginLeft: this.marginLeft + "px",
        marginTop: this.marginTop + "px",
        transform: "scale(" + this.scaling + ")"
      };
    },
    statusText() {
      return (
        this.width +
        "×" +
        this.height +
        " @ " +
        Math.round(this.scaling * 100) +
        "%"
      );
    }
  },
  created() {
    var _this = this;
    documentEvent.$on("switchTool", function(tool) {
      if (tool == "zoomIn") {
        _this.scalingUp(0.1, 0,0);
      } else if (tool == "zoomOut") {
        _this.scalingUp(-0.1, 0,0);
      }
    });
  },
  mounted() {
    let _this = this;
    window.addEventListener(
      "keydown",
      function(event) {
        if (event.altKey) {
          _this.isAltKeyPress = true;
        }
      },
      false
    );

    window.addEventListener(
      "keyup",
      function() {
        _this.isAltKeyPress = false;
      },
      false
    );
  },
  methods: {
    close() {
      this.$emit("close");
    },
    scalingUp(increament, X, Y) {
      let oldScaling = this.scaling;
      this.changeScaling += increament;

      let isInnerOfWidth =
        this.width * this.scaling < this.$refs.board.offsetWidth;
      let isInnerOfHight =
        this.height * this.scaling < this.$refs.board.offsetHeight;

      if (isInnerOfWidth) {
        this.left = "50%";
        this.marginLeft = (-1 * this.width * this.scaling) / 2;
      } else {
        this.left = 0;
        this.marginLeft = 20;
        //                    this.$refs.board.scrollLeft = this.scaling * (this.$refs.board.scrollLeft + X) / oldScaling - X;
      }

      if (isInnerOfHight) {
        this.top = "50%";
        this.marginTop = (-1 * this.height * this.scaling) / 2;
      } else {
        this.top = 0;
        this.marginTop = 20;
        //                  this.$refs.board.scrollTop = this.scaling * (this.$refs.board.scrollTop + Y) / oldScaling - Y;
      }
    },
    onmouseup(event) {},
    onmousedown(event) {},
    onwheel(event) {
      let board = this.$refs.board;
      if (event.ctrlKey) {
        console.log("----------ctrlKey");
        //If the ctrl key is pressed, slide the scroll wheel to move the canvas left and right
        if (event.deltaY > 0) {
          board.scrollLeft += 200;
        } else {
          board.scrollLeft -= 200;
        }
        event.preventDefault();
        return false;
      } else if (event.altKey) {
        //If the alt key is pressed, the canvas is zoomed
        if (event.deltaY < 0) {
          this.scalingUp(0.4, event.screenX, event.screenY);
        } else {
          this.scalingUp(-0.4, event.screenX, event.screenY);
        }
        event.preventDefault();
        return false;
      }
    }
  }
};

function getPositionOnParent(element, parentElement) {
  let actualLeft = element.offsetLeft;
  let actualTop = element.offsetTop;

  let current = element.offsetParent;
  while (current !== parentElement) {
    actualLeft += current.offsetLeft;
    actualTop += current.offsetTop;
    current = current.offsetParent;
  }

  return {
    x: actualLeft,
    y: actualTop
  };
}
</script>

<style lang="scss" scoped="">
ul > li {
  display: inline-block;
  margin-right: 0.2em;
}
.board {
  position: absolute;
  top: 40px;
  left: 0;
  bottom: 1.5em;
  width: 100%;
  overflow: scroll;
  margin: 0;
}
ul.canvases {
  position: relative;
  transform-origin: 0 0;
  margin-right: 20px;
  // margin-bottom: 20px;
  -webkit-transition: all 0.5s;
  -moz-transition: all 0.5s;
  -ms-transition: all 0.5s;
  -o-transition: all 0.5s;
  transition: all 0.5s;
}
ul.canvases li {
  position: absolute;
  top: 0;
  left: 0;
}
.zoom {
  cursor: zoom-in;
}
.zoom-alt {
  cursor: zoom-out;
}
.status {
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  font-size: 1em;
  line-height: 2em;
  background: #e0e0e0;
  padding-left: 1em;
  margin-top: 0.2em;
}
</style>
