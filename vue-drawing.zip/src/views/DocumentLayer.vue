<template>
  <li style="background-color:white">
    <!-- <canvas ref="canvas"></canvas> -->
      <!-- <div
          v-for="item in docInfo.items"
          :key="item.id"
        >
        <p>{{item}}</p>
      </div> -->
    <v-stage
      ref="stage"
      :config="docInfo"
      @mousedown="handleStageMouseDown"
      @touchstart="handleStageMouseDown"
      @mouseup="handleStageMouseUp"
      @touchend="handleStageMouseUp"
    >
      <v-layer ref="layer">
        <component
          :is="'v-' + item.tag"
          v-for="item in drawingItems"
          :key="item.id"
          :config="item"
          @transformend="handleTransformEnd"
          @dragend="handleTransformEnd"
          @dblclick="handleDblClk"
        />
        <v-transformer ref="transformer" />
      </v-layer>
    </v-stage>
  </li>
</template>

<script>
import { mapGetters, mapMutations } from "vuex";
import _ from 'lodash'
import documentEvent from './document-event';
import Vue from 'vue';

export default {
  props: {
    id: Number,
    image: Image,
    docInfo: Object,
  },
  data() {
    return {
      stageSize: {
        width: 1080,
        height: 1920
      },
      items: [
      ],
      selectedItemName: "",
      selectedItem: {},
      undoItem: {},
      isEditing: false
    };
  },
  computed: {
    ...mapGetters(["foreColor", "backColor"]),
    drawingItems() {
      let _this = this
      return this.docInfo.items.filter((item)=>{
        if (_this.isEditing && item == _this.selectedItem){
          console.log('---------drawing:', false)
          return false;
        } 
        return true;
      });
    }
  },
  created() {
    var _this = this;
    documentEvent.$on("switchTool", function(tool, value) {
      if (tool == "undo") {
        if (_this.selectedItem && _this.undoItem) {
          _this.selectedItem.x = _this.undoItem.x;
          _this.selectedItem.y = _this.undoItem.y;
          _this.selectedItem.scaleX = _this.undoItem.scaleX;
          _this.selectedItem.scaleY = _this.undoItem.scaleY;
          _this.selectedItem.rotation = _this.undoItem.rotation;
        }
      } else if (tool == "foreColor") {
        if (_this.selectedItem ) {
          _this.selectedItem.stroke = '#' + _this.foreColor;
          console.log('_this.selectedItem:', _this.selectedItem)
        }
      } else if (tool == "backColor") {
        if (_this.selectedItem ) {
          _this.selectedItem.fill = '#' + _this.backColor;
          console.log('_this.selectedItem:', _this.selectedItem)
        }
      }
    });
  },
  mounted() {
    this.stageSize.width = this.docInfo.width;
    this.stageSize.height = this.docInfo.height;
    this.items = _.clone(this.docInfo.items);
    this.isEditing = false;
  },
  methods: {
    updateItemState(x,y, scaleX, scaleY, rotation) {
     // console.log('----------handleTransformEnd:', this.docInfo)
      // shape is transformed, let us save new attrs back to the node
      // find element in our state
      const item = this.docInfo.items.find(r => r.name === this.selectedItemName);
      // update the state
      // console.log('----------handleTransformEnd1:', item)
      item.x = x;
      item.y = y;
      item.scaleX = scaleX;
      item.scaleY = scaleY;
      item.rotation = rotation;
      // change fill
      // rect.fill = Konva.Util.getRandomColor();
    },
    handleTransformEnd(e) {
      // console.log('-------------------handleTransformEnd:', e)
      this.updateItemState(e.target.x(), e.target.y(), e.target.scaleX(), e.target.scaleY(), e.target.rotation());
    },
    handleDblClk(e) {
      const item = this.docInfo.items.find(r => r.name === this.selectedItemName);
      this.isEditing = true;
      // e.target.hide();
      const transformerNode = this.$refs.transformer.getNode();
      transformerNode.detach();

      let textNode = e.target;
      const stage = transformerNode.getStage();      
      var stageBox = stage.container().getBoundingClientRect();
      var textPosition = textNode.absolutePosition();
      var areaPosition = {
        x: stageBox.left + textPosition.x,
        y: stageBox.top + textPosition.y,
      };
       // create textarea and style it
        var textarea = document.createElement('textarea');
        document.body.appendChild(textarea);

        // apply many styles to match text on canvas as close as possible
        // remember that text rendering on canvas and on the textarea can be different
        // and sometimes it is hard to make it 100% the same. But we will try...
        textarea.value = textNode.text();
        textarea.style.position = 'absolute';
        textarea.style.top = areaPosition.y + 'px';
        textarea.style.left = areaPosition.x + 'px';
        textarea.style.width = textNode.width() - textNode.padding() * 2 + 'px';
        textarea.style.height =
        textNode.height() - textNode.padding() * 2 + 5 + 'px';
        textarea.style.fontSize = textNode.fontSize() + 'px';
        textarea.style.border = 'none';
        textarea.style.padding = '0px';
        textarea.style.margin = '0px';
        textarea.style.overflow = 'hidden';
        textarea.style.background = 'none';
        textarea.style.outline = 'none';
        textarea.style.resize = 'none';
        textarea.style.lineHeight = textNode.lineHeight();
        textarea.style.fontFamily = textNode.fontFamily();
        textarea.style.transformOrigin = 'left top';
        textarea.style.textAlign = textNode.align();
        textarea.style.color = textNode.fill();
        textarea.style.zIndex = 500;
        // rotation = textNode.rotation();
        var transform = '';
        // if (rotation) {
        //   transform += 'rotateZ(' + rotation + 'deg)';
        // }
        var px = 0;
        // also we need to slightly move textarea on firefox
        // because it jumps a bit
        var isFirefox =
          navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
        if (isFirefox) {
          px += 2 + Math.round(textNode.fontSize() / 20);
        }
        transform += 'translateY(-' + px + 'px)';

        textarea.style.transform = transform;

        // reset height
        textarea.style.height = 'auto';
        // after browsers resized it we can set actual value
        textarea.style.height = textarea.scrollHeight + 3 + 'px';

        textarea.focus();
        
        function removeTextarea() {
          textarea.parentNode.removeChild(textarea);
          window.removeEventListener('click', handleOutsideClick);
          // textNode.show();
          // transformerNode.show();
          // transformerNode.forceUpdate();
          // layer.draw();
        }
        function setTextareaWidth(newWidth) {
          if (!newWidth) {
            // set width for placeholder
            newWidth = textNode.placeholder.length * textNode.fontSize();
          }
          // some extra fixes on different browsers
          var isSafari = /^((?!chrome|android).)*safari/i.test(
            navigator.userAgent
          );
          var isFirefox =
            navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
          if (isSafari || isFirefox) {
            newWidth = Math.ceil(newWidth);
          }

          var isEdge =
            document.documentMode || /Edge/.test(navigator.userAgent);
          if (isEdge) {
            newWidth += 1;
          }
          textarea.style.width = newWidth + 'px';
        }
        textarea.addEventListener('keydown', function (e) {
          // hide on enter
          // but don't hide on shift + enter
          if (e.keyCode === 13 && !e.shiftKey) {
            textNode.text(textarea.value);
            removeTextarea();
          }
          // on esc do not set value back to node
          if (e.keyCode === 27) {
            removeTextarea();
          }
        });

        textarea.addEventListener('keydown', function (e) {
          let scale;
          scale = textNode.getAbsoluteScale().x;
          setTextareaWidth(textNode.width() * scale);
          textarea.style.height = 'auto';
          textarea.style.height =
            textarea.scrollHeight + textNode.fontSize() + 'px';
        });

        var _this = this
        function handleOutsideClick(e) {
          if (e.target !== textarea) {
            // textNode.text(textarea.value);
            // textNode.show();
            item.text = textarea.value;
            removeTextarea();
            _this.isEditing = false;
            _this.selectedItem = {}            
          }
        }
        setTimeout(() => {
          window.addEventListener('click', handleOutsideClick);
        });                    
    },
    handleStageMouseDown(e) {
      // console.log('----------handleStageMouseDown:')
      // clicked on stage - clear selection
      if (e.target === e.target.getStage()) {
        this.selectedItemName = "";
        this.selectedItem = {};
        this.undoItem = {};
        this.updateTransformer();
        return;
      }

      // clicked on transformer - do nothing
      const clickedOnTransformer =
        e.target.getParent().className === "Transformer";
      if (clickedOnTransformer) {
        return;
      }

      // find clicked rect by its name
      const name = e.target.name();
      const item = this.docInfo.items.find(r => r.name === name);

      if (item) {
        this.undoItem = _.clone(item);
        this.selectedItem = item;
        this.selectedItemName = name;
        // console.log('---------------selectedItem:', this.selectedItem, this.undoItem)
      } else {
        this.selectedItemName = "";
      }
      this.updateTransformer();
    },
    handleStageMouseUp() {
      // const item = this.docInfo.items.find(r => r.name === name);
      // if (!item) {
      //   this.selectedItemName = ''
      //   this.selectedItem = {}
      //   this.isEditing = false
      // }
    },
    updateTransformer() {
      // console.log('----------updateTransformer:')

      // here we need to manually attach or detach Transformer node
      const transformerNode = this.$refs.transformer.getNode();
      const stage = transformerNode.getStage();
      const { selectedItemName } = this;

      const selectedNode = stage.findOne("." + selectedItemName);
      // do nothing if selected node is already attached

      if (selectedNode === transformerNode.node()) {
        return;
      }

      if (selectedNode) {
        // attach to another node
        transformerNode.attachTo(selectedNode);
      } else {
        // remove transformer
        transformerNode.detach();
      }
      transformerNode.getLayer().batchDraw();
    }
  }
};
</script>

<style></style>
