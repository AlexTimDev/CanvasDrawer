import { $ } from "./element";

/**
 * Shortcut key object, responsible for managing shortcut keys
 */
var hotkey = (function() {
  var _registeredHotkeys = [];

  function addHotkeyHint(key, targetId) {
    var $target = $("#" + targetId);
    if (targetId.match(/menu-/) || $(".menu #" + targetId)) {
      //Add shortcut keys to menu items
      let $hotkeyHint = document.createElement("span");
      $hotkeyHint.className = "hotkey-hint";
      $hotkeyHint.innerText = key.replace(/(^[a-z]|\b[a-z])/g, match => {
        return match.toUpperCase();
      });
      $target.appendChild($hotkeyHint);
      $target.addClass("hasHotkey");
    } else {
      //Add shortcut keys to buttons
      $target.title += "(" + key + ")";
    }
  }

  function registerHotkey(key, targetId) {
    var testingKey = new RegExp(
        /^((Ctrl|ctrl|Alt|alt|Shift|shift)\+)*[A-Za-z0-9]$/
      ),
      $target = $("#" + targetId),
      stateKeys = key.match(/(Ctrl|ctrl|Alt|alt|Shift|shift)/),
      mainKey = key.substring(key.length - 1);

    //If this key has already been registered/incorrect format/pointing target does not exist, end and return false
    if (_registeredHotkeys.includes(key) || !testingKey.test(key) || !$target) {
      return false;
    }

    document.addEventListener(
      "keypress",
      function(event) {
        var isStateKeysDown = true;
        stateKeys &&
          stateKeys.forEach(function(stateKey) {
            isStateKeysDown =
              isStateKeysDown && event[stateKey.toLowerCase() + "Key"];
          });
        if (
          isStateKeysDown &&
          event.key.toUpperCase() === mainKey.toUpperCase()
        ) {
          event.preventDefault();
          $target.click();
          return false;
        }
      },
      false
    );

    addHotkeyHint(key, targetId);
    _registeredHotkeys.push(key);
  }

  function loadKeymap(keymap) {
    keymap &&
      Object.keys(keymap).forEach(function(part) {
        part &&
          Object.keys(keymap[part]).forEach(function(command) {
            registerHotkey(keymap[part][command], part + "-" + command);
          });
      });
  }

  // function loadKeymapJSON (filePath) {
  // 	var xhr = new XMLHttpRequest();
  // 	xhr.onreadystatechange = function () {
  // 		if (xhr.readyState === 4) {
  // 			if ((xhr.status >= 200 && xhr.status < 300) || xhr.status === 304) {
  // 				alert(xhr.responseText);
  // 			} else {
  // 				console.log('request keymap.json failed, status: ' + xhr.status);
  // 			}
  // 		}
  // 	}
  // 	xhr.open('data', filePath, true);
  // 	xhr.send(null);
  // }

  return {
    registerHotkey: registerHotkey,
    loadKeymap: loadKeymap,
    addHotkeyHint: addHotkeyHint
  };
})();

let defaultKeymap = {
  menu: {
    new: "",
    openFromLocal: "Ctrl+O"
  },
  tool: {
    move: "V",
    crop: "C",
    eyedropper: "I",
    blush: "B",
    eraser: "E",
    text: "T",
    rect: "U",
    hand: "H",
    zoom: "Z"
  },
  color: {
    reset: "D",
    exchange: "X"
  }
};

export default hotkey;
