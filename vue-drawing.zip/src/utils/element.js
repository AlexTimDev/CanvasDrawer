/**
 * query selector
 * @param selector {String} selector
 * @returns {*} {Node/NodeList} If it is an id selector, return a single element, otherwise it returns a NodeList
 */
export function $(selector) {
  return document.querySelector(selector);
}

export function $$(selector) {
  return document.querySelectorAll(selector);
}

NodeList.prototype.forEach = function(callback) {
  for (var i = 0, item; (item = this[i++]); ) {
    callback(item, i - 1);
  }
};

HTMLCollection.prototype.forEach = NodeList.prototype.forEach;

/**
 * Add a class name to an element
 * @param className {string} Class name to add
 */
Element.prototype.addClass = function(className) {
  if (this.className === "") {
    this.className = className;
  } else {
    this.className += " " + className;
  }
};

/**
 * Remove a class name of an element
 * @param className {string} The name of the class to be removed
 * @returns {boolean} If the class name cannot be found, false is returned, and successful removal returns true
 */
Element.prototype.removeClass = function(className) {
  var regExpMatch = new RegExp(
    "^" +
      className +
      "$|^" +
      className +
      " +| +" +
      className +
      "$| +" +
      className +
      " +"
  );

  if (this.className.match(regExpMatch)) {
    //Find the matching class name
    this.className = this.className.replace(regExpMatch, "");
    return true;
  } else {
    //The class name cannot be found
    return false;
  }
};

Element.prototype.disabled = function() {
  this.addClass("disabled");
};

Element.prototype.enable = function() {
  this.removeClass("disabled");
};

/**
 * Get the distance of a webpage element from the left of the browser
 * @returns {number} The distance of the web page element from the left of the browser
 */
Element.prototype.getViewOffsetLeft = function() {
  var actualLeft = this.offsetLeft;
  var current = this.offsetParent;
  while (current !== null) {
    actualLeft += current.offsetLeft;
    current = current.offsetParent;
  }
  var elementScrollLeft;
  if (document.compatMode == "BackCompat") {
    elementScrollLeft = document.body.scrollLeft;
  } else {
    elementScrollLeft = document.documentElement.scrollLeft;
  }
  return actualLeft - elementScrollLeft;
};

/**
 * Get the distance of webpage elements from the top of the browser
 * @returns {number} The distance of web page elements from the top of the browser
 */
Element.prototype.getViewOffsetTop = function() {
  var actualTop = this.offsetTop;
  var current = this.offsetParent;
  while (current !== null) {
    actualTop += current.offsetTop;
    current = current.offsetParent;
  }
  var elementScrollTop;
  if (document.compatMode == "BackCompat") {
    elementScrollTop = document.body.scrollTop;
  } else {
    elementScrollTop = document.documentElement.scrollTop;
  }
  return actualTop - elementScrollTop;
};

/**
 * Let an element play an animation (by switching the class name), which can be triggered multiple times
 * @param $element {Element} The element to be animated
 * @param classBefore {String} Before playing, there is no animation attribute class
 * @param classAfter {String} Class with animation attribute
 */
Element.prototype.playAnimation = function(classBefore, classAfter) {
  this.className = classBefore;
  console.log('---------------playAnimation:', this)
  window.requestAnimationFrame(function(time) {
    window.requestAnimationFrame(function(time) {
      this.className = classAfter;
      console.log('---------------playAnimation1:', this)
    });
  });
};

String.prototype.trimLength = function(length) {
  if (this.length > length) {
    return this.substr(0, length) + "...";
  } else {
    return this;
  }
};
String.prototype.firstUpperCase = function() {
  return this.replace(/^\S/, function(s) {
    return s.toUpperCase();
  });
};
