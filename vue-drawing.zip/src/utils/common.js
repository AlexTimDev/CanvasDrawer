/**
 * Created by on 2020/07/02.
 */

/**
 * Function to make the browser full screen
 * @type {{launchFullscreen: fullScreen.launchFullscreen, exitFullscreen: fullScreen.exitFullscreen}}
 */
var fullScreen = {
  launchFullscreen: function(element) {
    if (element.requestFullscreen) {
      element.requestFullscreen();
    } else if (element.mozRequestFullScreen) {
      element.mozRequestFullScreen();
    } else if (element.msRequestFullscreen) {
      element.msRequestFullscreen();
    } else if (element.webkitRequestFullscreen) {
      element.webkitRequestFullScreen();
    }
  },
  exitFullscreen: function() {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    } else if (document.msExitFullscreen) {
      document.msExitFullscreen();
    } else if (document.mozCancelFullScreen) {
      document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
    }
  }
};

/**
 * Make an element can be dragged by the mouse to change the position
 * @param $enable Elements that can be dragged
 * @param $move The element being dragged
 */
var setDragMoving = function($enable, $move) {
  var isDraging = false;
  var oldPosX, oldPosY, startPosX, startPosY;

  /**
   * Keep the floating layer in the screen
   * @param pos {Number} Floating layer coordinates
   * @param maxPos {Number} The maximum coordinates of the floating layer
   * @returns {Number} corrected coordinates
   */
  var getPosInScreen = function(pos, maxPos) {
    if (pos < 0) {
      return 0;
    } else if (pos > maxPos) {
      return maxPos;
    } else {
      return pos;
    }
  };

  $enable.addEventListener("mousedown", function(event) {
    isDraging = true;
    //Save the current position of the object to be moved
    oldPosX = parseInt($move.style.left.split("px")[0]);
    oldPosY = parseInt($move.style.top.split("px")[0]);
    //Save the current position of the mouse
    startPosX = event.screenX;
    startPosY = event.screenY;
    return false; //Prevent the browser from selecting content
  });

  window.addEventListener("mouseup", function() {
    isDraging = false;
  });

  window.addEventListener("mousemove", function(event) {
    if (isDraging) {
      //Current coordinates = coordinates of the floating layer when dragging starts + coordinates of mouse movement
      var currentPosX = oldPosX + event.screenX - startPosX;
      var currentPosY = oldPosY + event.screenY - startPosY;

      //Maximum drag range
      var maxPosX = window.innerWidth - $move.offsetWidth;
      var maxPosY = window.innerHeight - $move.offsetHeight;

      //Modify the current coordinates to keep the floating layer in the screen
      currentPosX = getPosInScreen(currentPosX, maxPosX);
      currentPosY = getPosInScreen(currentPosY, maxPosY);

      $move.style.left = currentPosX + "px";
      $move.style.top = currentPosY + "px";
    }
  });
};

/**
 * Get the selected element of a radio
 * @param radioName {String} The name attribute to get
 * @returns {HTMLInputElement} selected element
 */
function getRadioCheckedElement(radioName) {
  var $radios = document.getElementsByName(radioName);
  for (var i = 0, item; (item = $radios[i++]); ) {
    if (item.checked) {
      return item;
    }
  }
}

/**
 * Traverse listening to radio change events
 * @param radioName {String} The name of the radio to be monitored
 * @param callback {Function} The callback for operating the newly selected element after change, this points to the newly selected element
 */
function listenRadioChange(radioName, callback) {
  var $radios = document.getElementsByName(radioName);
  $radios.forEach(function(item) {
    item.addEventListener("change", function() {
      if (this.checked) {
        return callback.call(this, arguments);
      }
    });
  });
}
