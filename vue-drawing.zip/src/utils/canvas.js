import { $, $$ } from "./element";

var $canvas = $("canvas");

function Canvas(background) {}
