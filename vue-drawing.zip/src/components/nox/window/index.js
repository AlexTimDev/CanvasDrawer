import WindowComponent from "./window.vue";
import windowEvent from "./window-event";

let Window = {
  "nox-window": WindowComponent
};

export { Window, windowEvent };
