<template>
  <ul class="menu">
    <slot></slot>
  </ul>
</template>

<script>
export default {};
</script>

<style scoped="">
ul {
  margin: 0;
  padding-left: 1em;
}
</style>
