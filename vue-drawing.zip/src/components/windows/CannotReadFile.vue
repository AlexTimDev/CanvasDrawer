<template>
  <div class="window" id="canNotReadLocalFile"></div>
</template>

<script>
export default {};
</script>

<style>
#canNotReadLocalFile {
  width: 40em;
}
#canNotReadLocalFile span {
  float: left;
  font-size: 9em;
}
#canNotReadLocalFile ul,
#canNotReadLocalFile h2 {
  clear: both;
}
</style>
