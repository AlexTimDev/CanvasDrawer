<template>
  <div id="about">
    <div class="logo">
      <!-- <img src="../../image/icon.png" alt=""> -->
      <h1>Drawing Shape</h1>
      <p class="version">V0.0.1</p>
    </div>
    <hr />
    <p>Copyright © 2020 JaySun</p>
  </div>
</template>

<script>
export default {};
</script>

<style>
#about {
  padding: 2em;
}
#about img {
  width: 5em;
  height: 5em;
  vertical-align: -1em;
}
#about h1 {
  display: inline-block;
  margin-left: 0.5em;
  font-size: 3em;
}
#about p {
  margin-left: 1em;
}
#about ul {
  list-style-type: none;
  margin-left: 2em;
}
#about li {
  margin: 1em 0;
}
#about li a {
  padding: 0.4em 0.6em;
  background: #414141;
  white-space: nowrap;
  text-decoration: none;
  color: #ffffff;
  transition: all 0.8s;
}
#about li a:hover {
  background: #313131;
}
</style>
