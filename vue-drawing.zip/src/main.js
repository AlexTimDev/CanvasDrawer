import Vue from "vue";
import App from "./views/App.vue";
import router from "./router";
import store from "./store";
import { BootstrapVue, IconsPlugin } from "bootstrap-vue";
import "./style.scss";
import "@/utils/element";
import { $ } from "@/utils/element";
import "@/utils/common";

import VueKonva from "vue-konva";

Vue.config.productionTip = false;
// Install BootstrapVue
Vue.use(BootstrapVue);
// Optionally install the BootstrapVue icon components plugin
Vue.use(IconsPlugin);
Vue.use(VueKonva);

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount("#app");
