import _ from 'lodash'

class DocumentService {
  constructor() {
    this.symbolImage = null;
    this.arrowImage = null;
    this.centerPos = {x:0, y:0};
    this.initResource();
  }
  initResource() {
    const symbolImage = new window.Image();
    const arrowImage = new window.Image();
    symbolImage.src = "assets/images/tools/symbol.png";
    arrowImage.src = "assets/images/tools/arrow.png";
    var _this = this;
    symbolImage.onload = () => {
      _this.symbolImage = symbolImage;
    }
    arrowImage.onload = () => {
      _this.arrowImage = arrowImage;
    }
  }
  getSymbolImage() {
    return this.symbolImage;
  }
  getArrowImage() {
    return this.arrowImage;
  }
  setCenterPos(x, y) {
    this.centerPos = {x, y};
  }
  getCenterPos() {
    return this.centerPos;
  }
}

export default new DocumentService()
