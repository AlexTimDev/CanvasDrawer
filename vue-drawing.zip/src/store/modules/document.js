function PixelDocument(fileName, width, height, backColor) {
  this.fileName = fileName ? fileName : ""; //_getUrlFileName(src);
  this.width = width;
  this.height = height;
  this.backColor = backColor;
  this.items = [];
}
function PixelItem(type, name) {
  this.type = type;
  this.name = name;
}
import DocumentService from "@/services/document";

export default {
  state: {
    pixelDocuments: [],
    activeDocument: null,
  },
  getters: {
    pixelDocuments: state => state.pixelDocuments,
    activeDocument: state => state.activeDocument,
    activeItems: state =>
      state.activeDocument ? state.activeDocument.items : []
  },
  mutations: {
    createDocument(state, documentInfo) {
      let fileName = documentInfo.fileName || "Unnamed";
      let width = documentInfo.width;
      let height = documentInfo.height;
      let backColor = documentInfo.backColor;
      let newDocument = new PixelDocument(fileName, width, height, backColor);

      state.pixelDocuments.push(newDocument);
      state.activeDocument = newDocument;
    },
    openDocument(state, documentInfo) {
      let fileName = documentInfo.fileName || "Unnamed";
      let width = documentInfo.width;
      let height = documentInfo.height;
      let backColor = documentInfo.backColor;
      let newDocument = new PixelDocument(fileName, width, height, backColor);

      for (let i=0; i<documentInfo.items.length; i++) {
        let item = documentInfo.items[i];
        if (item.type == "symbol") {
          item.image = DocumentService.getSymbolImage();
        } else if (item.type == "arrow") {
          item.image = DocumentService.getArrowImage();
        }
      }
      newDocument.items = documentInfo.items;
      state.pixelDocuments.push(newDocument);
      state.activeDocument = newDocument;
    },
    closeDocument(state, pixelDocument) {
      let index = state.pixelDocuments.indexOf(pixelDocument);
      state.pixelDocuments.splice(index, 1);

      if (state.pixelDocuments[index]) {
        state.activeDocument = state.pixelDocuments[index];
      } else if (state.pixelDocuments[index - 1]) {
        state.activeDocument = state.pixelDocuments[index - 1];
      } else {
        state.activeDocument = null;
      }
    },
    switchTo(state, pixelDocument) {
      state.activeDocument = pixelDocument;
    },
    newPixelItem(state, itemInfo) {
      if (state.activeDocument == null) return;
      if (itemInfo.type != "symbol" && itemInfo.type != "shape" && itemInfo.type != "arrow" && itemInfo.type != "text") return;

      let item = {};
      item.type = itemInfo.type;
      item.name = `${item.type}-${new Date()}`;
      item.name = item.name.split(" ").join("");
      item.x = 100;
      item.y = 100;
      item.width = 100;
      item.scaleX = 1;
      item.scaleY = 1;
      item.rotation = 0;
      item.draggable = true;

      switch (item.type) {
        case "symbol": {
          item.tag = "image";
          item.image = DocumentService.getSymbolImage();
          item.width = 32;
          item.height = 32;
          break;
        }
        case "arrow": {
          item.tag = "image";
          item.image = DocumentService.getArrowImage();
          item.width = 32;
          item.height = 32;
          break;
        }
        case "shape": {
          item.tag = "rect";
          item.fill = itemInfo.backColor;
          item.stroke = itemInfo.foreColor;
          item.strokeWidth = 2;
          item.height = 100;
          break;
        }
        case "text": {
          item.tag = "text";
          item.width = 200;
          item.text = "Draggable Text";
          item.fontSize = 25;
          item.fontFamily = "Roboto";
          break;
        }        
      }
      state.activeDocument.items.push(item);
    }
  }
};
