export default {
  state: {
    toolbarShow: true,
    activeTool: "move"
  },
  getters: {
    isShowToolbar: state => state.toolbarShow,
    activeTool: state => state.activeTool
  },
  mutations: {
    showToolbar(state, flag) {
      console.log('-------------showToolbar:', flag)
      state.toolbarShow = flag;
    },
    switchTool(state, tool) {
      state.activeTool = tool;
    }
  }
};
